package accesDonnees;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connexion {

	private Connection con = null;
	
	public Connection connect()
	{
		// chargement du pilote
	      try {
	         Class.forName("com.mysql.jdbc.Driver");
	      } catch (ClassNotFoundException e) {
	         System.out.println("Impossible de charger le pilote ");
	      }
	      
	      //connection a la base de donn�es
	      System.out.println("connexion a la base de donn�es");
	      try {

	         String DBurl = "jdbc:mysql://localhost:3306/chat";
	         con = DriverManager.getConnection(DBurl,"root","root");
	         return con;
	      } catch (SQLException e) {
	         System.out.println("Connection � la base de donn�es impossible");
	      }
	      
	      return null;
	}
}
