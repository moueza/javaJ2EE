package accesDonnees;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import bean.User;

public class UserDao{

	Connexion connec = new Connexion();
	private Connection con = null;
	private ResultSet result = null;
	private String requete = "";
	static UserDao instance;
	
	public static UserDao getInstance() {
		if (instance == null)
			instance = new UserDao();

		return instance;
	}
	
	
	public void addUser(User user)
	{
		con = connec.connect();
		
		requete = "INSERT INTO user (pseudo, pwd) VALUES ('" + user.getPseudo() + "', '"+ user.getPwd() + "');";
		
		java.sql.Statement stmt = null;
		
		try {
			stmt = con.createStatement();
			stmt.executeUpdate(requete);
			stmt.close();
			con.close();
		} catch (SQLException e) {
			System.out.println("Anomalie lors de l'execution de la requ�te");
		}
	}
	
	public void delUser()
	{
		con = connec.connect();
		
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getPwdUser(String pseudo)
	{
		String pwd = "";
		con = connec.connect();
		

		requete = "SELECT pwd FROM user WHERE pseudo = '"+ pseudo +"'";
		
		java.sql.Statement stmt = null;
		
		try {
			stmt = con.createStatement();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		java.sql.Statement stmt1 = null;
		
		try {
			stmt1 = con.createStatement();
			result = stmt1.executeQuery(requete);
		} catch (SQLException e) {
			System.out.println("Anomalie lors de l'execution de la requ�te");
		}
		
		
		// parcours des donn�es retourn�es
		
		
		try {
			
			while (result.next()) {
				pwd = result.getString("pwd");
			}
			
			System.out.println(pwd);
			
			result.close();
			stmt1.close();
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return pwd;
	}
}
