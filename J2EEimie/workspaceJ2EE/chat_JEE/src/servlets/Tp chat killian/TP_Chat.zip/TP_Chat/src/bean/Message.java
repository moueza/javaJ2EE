package bean;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Message implements Comparable<Object> {

	private String 		senderName;
	private String		date;
	private String 		msgContent;
	
	public Message() {

	}
	
	public String getSenderName() {
		return this.senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public String getDate() {
		return this.date;
	}

	public void setDate(Calendar date) {
		this.date = new SimpleDateFormat("dd/MM/YYYY hh:mm:ss").format(date.getTime());
	}

	public String getMsgContent() {
		return this.msgContent;
	}

	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}
	
	@Override
	public int compareTo(Object arg0) {
		Date thisMsgDate;
		Date msgDateToCompare;
		Integer result = 0;
		
		try {
			thisMsgDate = SimpleDateFormat.getInstance().parse(this.date);
			msgDateToCompare = SimpleDateFormat.getInstance().parse((String) arg0);
			result = thisMsgDate.compareTo(msgDateToCompare);
		} catch (ParseException e) {
			System.out.println(e.getMessage());
		}
		
		return result;
	}

}
