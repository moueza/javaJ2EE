package service;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import bean.Message;

public class MessageService {

	private static MessageService INSTANCE = null;
	private List<Message> lstMsg;

	private MessageService() {
		this.lstMsg = new ArrayList<Message>();
	}
	
	public static MessageService getInstance() {
		if(null == INSTANCE) {
			INSTANCE = new MessageService();
		}
		return INSTANCE;
	}
	
	public List<Message> getLstMsg() {
		return this.lstMsg;
	}

	public void addMessage(String senderName, String msgContent) {
		Message msg = new Message();
		msg.setSenderName(senderName);
		msg.setDate(Calendar.getInstance());
		msg.setMsgContent(msgContent);
		this.lstMsg.add(msg);
	}
	
	
}
