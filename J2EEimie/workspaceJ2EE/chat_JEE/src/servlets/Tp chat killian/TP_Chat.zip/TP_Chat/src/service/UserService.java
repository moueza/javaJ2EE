package service;

import java.util.ArrayList;
import java.util.List;

import bean.User;

public class UserService {

	private static UserService INSTANCE = null;
	private List<User> lstUser;

	private UserService() {
		this.lstUser = new ArrayList<User>();
	}
	
	public static UserService getInstance() {
		if(null == INSTANCE) {
			INSTANCE = new UserService();
		}
		return INSTANCE;
	}

	public void addUser(String pseudo) {
		User user = new User();
		user.setPseudo(pseudo);
	}
}
